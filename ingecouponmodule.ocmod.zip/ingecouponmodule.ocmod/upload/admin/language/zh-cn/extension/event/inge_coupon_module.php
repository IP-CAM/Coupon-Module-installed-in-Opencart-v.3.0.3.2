<?php

$_['text_news']                      = '优惠券管理';
$_['text_news_post']                 = '优惠券设置';
$_['text_news_category']             = '用户优惠券列表';
$_['text_news_review']               = 'Review';
$_['text_news_author']               = 'Author';
$_['text_news_author_group']         = 'Author Group';
$_['text_news_settings']             = 'Settings';