<?php

$_['text_coupon']                      = '优惠券管理';
$_['text_coupon_list']                 = '优惠券设置';
$_['text_coupon_user']                 = '用户优惠券列表';