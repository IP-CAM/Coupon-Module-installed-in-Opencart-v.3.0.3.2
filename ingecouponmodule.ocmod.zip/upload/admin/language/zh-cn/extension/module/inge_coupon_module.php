<?php
/*
 *  location: admin/language
 */

//heading
$_['heading_title']                             = '<span style="color:#449DD0; font-weight:bold">优惠券管理</span>';
$_['heading_title_main']                        = '优惠券管理模块';
$_['text_edit']                                 = '配置优惠券模块';
$_['text_extension']                               = '扩展';

$_['demonstration']                    = '<h4>欢迎来到优惠券管理模块</h4>
<p>优惠券管理插件跟系统自带的插件系统相互独立，可以各自配置优惠券，插件中配置的优惠券功能更多一些，建议直接使用插件中的功能，以免出现意料之外的冲突。</p>';